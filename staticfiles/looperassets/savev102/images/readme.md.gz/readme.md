Some image(s) are beautiful illustrations used in templates, is a wonderful work of:

* [UI Faces](https://uifaces.com/)
* [404 illustration](https://www.freepik.com/free-vector/404-error-design-with-space_1535242.htm)
