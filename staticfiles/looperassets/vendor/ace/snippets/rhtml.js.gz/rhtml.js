define("ace/snippets/rhtml",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText = "";
exports.scope = "rhtml";

});
                (function() {
                    window.require(["ace/snippets/rhtml"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            