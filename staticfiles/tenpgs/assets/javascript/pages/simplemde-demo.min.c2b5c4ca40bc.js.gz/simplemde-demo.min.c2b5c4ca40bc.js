"use strict";var simpleMDEDemo={init:function(){this.bindUIActions()},bindUIActions:function(){this.handleSimpleMDE()},handleSimpleMDE:function(){new SimpleMDE({element:$("#simplemde")[0],spellChecker:!1,autosave:{enabled:!0,unique_id:"SimpleMDEDemo"}})}};simpleMDEDemo.init();
//# sourceMappingURL=../../sourcemaps/pages/simplemde-demo.min.js.map
